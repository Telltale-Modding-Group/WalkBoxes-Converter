﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using wbox_console.Utilities;
using wbox_console.Telltale;

namespace wbox_console
{
    class Program
    {
        private static string wboxExt = ".wbox";
        private static string directory = "C:/Users/david/Desktop/telltale-wbox/de-wboxes";

        private static void Main(string[] args)
        {
            GetFilesInDirectory();
        }

        private static void GetFilesInDirectory()
        {
            //gather the files from the folder path into an array
            List<string> files = new List<string>(Directory.GetFiles(directory));

            ConsoleFunctions.SetConsoleColor(ConsoleColor.Black, ConsoleColor.Yellow);
            Console.WriteLine("Filtering Files..."); //notify the user we are filtering the array

            //filter the array so we only get .d3dtx files
            files = IOManagement.FilterFiles(files, wboxExt);

            //if no d3dtx files were found, abort the program from going on any further (we don't have any files to convert!)
            if (files.Count < 1)
            {
                ConsoleFunctions.SetConsoleColor(ConsoleColor.Black, ConsoleColor.Red);
                Console.WriteLine("No {0} files were found, aborting.", wboxExt);
                Console.ResetColor();
                return;
            }

            ConsoleFunctions.SetConsoleColor(ConsoleColor.Black, ConsoleColor.Green);
            Console.WriteLine("Found {0} WalkBoxes.", files.Count.ToString()); //notify the user we found x amount of d3dtx files in the array
            Console.WriteLine("Starting...");//notify the user we are starting
            Console.ResetColor();

            //run a loop through each of the found textures and convert each one
            foreach (string file in files)
            {
                //build the path for the resulting file
                string fileName = Path.GetFileName(file); //get the file name of the file + extension
                //string textureFileNameOnly = Path.GetFileNameWithoutExtension(texture);
                //string textureResultPath = resultPath + "/" + textureFileNameOnly + DDS_File.ddsExtension; //add the file name to the resulting folder path, this is where our converted file will be placed

                ConsoleFunctions.SetConsoleColor(ConsoleColor.Black, ConsoleColor.White);
                Console.WriteLine("||||||||||||||||||||||||||||||||");
                ConsoleFunctions.SetConsoleColor(ConsoleColor.Black, ConsoleColor.Blue);
                Console.WriteLine("Converting '{0}'...", fileName); //notify the user are converting 'x' file.
                Console.ResetColor();

                ReadWalkBox(file);

                ConsoleFunctions.SetConsoleColor(ConsoleColor.Black, ConsoleColor.Green);
                Console.WriteLine("Finished converting '{0}'...", fileName); //notify the user we finished converting 'x' file.
                ConsoleFunctions.SetConsoleColor(ConsoleColor.Black, ConsoleColor.White);
            }
        }

        public static void ReadWalkBox(string filePath)
        {
            byte[] fileBytes = File.ReadAllBytes(filePath);
            uint bytePointerPosition = 0;

            Console.WriteLine("File Size: '{0}'", fileBytes.Length);

            string MagicHeader = ByteFunctions.ReadFixedString(fileBytes, 4, ref bytePointerPosition);
            Console.WriteLine("MagicHeader: '{0}'", MagicHeader);

            uint mData = ByteFunctions.ReadUnsignedInt(fileBytes, ref bytePointerPosition);
            Console.WriteLine("mData: '{0}'", mData);

            uint HeaderLength = (uint)fileBytes.Length - mData;
            bytePointerPosition = HeaderLength;

            //check what this value is in IDA
            uint Unknown1 = ByteFunctions.ReadUnsignedInt(fileBytes, ref bytePointerPosition);
            Console.WriteLine("Unknown1: '{0}'", Unknown1);

            uint mNameLength = ByteFunctions.ReadUnsignedInt(fileBytes, ref bytePointerPosition);
            Console.WriteLine("mNameLength: '{0}'", mNameLength);

            WalkBoxes walkBoxes = new WalkBoxes();

            walkBoxes.mName = ByteFunctions.ReadFixedString(fileBytes, mNameLength, ref bytePointerPosition);

            uint mTrisSize = ByteFunctions.ReadUnsignedInt(fileBytes, ref bytePointerPosition);
            Console.WriteLine("mTrisSize: '{0}'", mTrisSize);

            walkBoxes.mTris = new Tri[mTrisSize];






            Tri mTri = walkBoxes.mTris[0];

            EnumMaterial mFootstepMaterial = (EnumMaterial)ByteFunctions.ReadUnsignedInt(fileBytes, ref bytePointerPosition);
            Console.WriteLine("mFootstepMaterial: '{0}'", mFootstepMaterial);

            int FlagsStructSize = ByteFunctions.ReadInt(fileBytes, ref bytePointerPosition);
            Console.WriteLine("FlagsStructSize: '{0}'", FlagsStructSize);

            mTri.mFlags = new Flags()
            {
                mFlags = ByteFunctions.ReadUnsignedInt(fileBytes, ref bytePointerPosition)
            };

            Console.WriteLine("mFlags: '{0}'", mTri.mFlags.mFlags);

            //mTri.mNormal = ByteFunctions.ReadLong(fileBytes, ref bytePointerPosition);
            mTri.mNormal = ByteFunctions.ReadInt(fileBytes, ref bytePointerPosition);
            Console.WriteLine("mNormal: '{0}'", mTri.mNormal);

            //mTri.mQuadBuddy = ByteFunctions.ReadLong(fileBytes, ref bytePointerPosition);
            mTri.mQuadBuddy = ByteFunctions.ReadInt(fileBytes, ref bytePointerPosition);
            Console.WriteLine("mQuadBuddy: '{0}'", mTri.mQuadBuddy);

            mTri.mMaxRadius = ByteFunctions.ReadFloat(fileBytes, ref bytePointerPosition);
            Console.WriteLine("mMaxRadius: '{0}'", mTri.mMaxRadius);

            int mVertsSize = ByteFunctions.ReadInt(fileBytes, ref bytePointerPosition);
            Console.WriteLine("mVertsSize: '{0}'", mVertsSize);

            int a1 = ByteFunctions.ReadInt(fileBytes, ref bytePointerPosition);
            Console.WriteLine("a1: '{0}'", a1);

            int a2 = ByteFunctions.ReadInt(fileBytes, ref bytePointerPosition);
            Console.WriteLine("a2: '{0}'", a2);

            int a3 = ByteFunctions.ReadInt(fileBytes, ref bytePointerPosition);
            Console.WriteLine("a3: '{0}'", a3);

            mTri.mVerts = new int[mVertsSize];

            /*
            for(uint i = 0; i < walkBoxes.mTris.Length; i++)
            {
                Tri mTri = walkBoxes.mTris[i];

                EnumMaterial mFootstepMaterial = (EnumMaterial)ByteFunctions.ReadUnsignedInt(fileBytes, ref bytePointerPosition);
                Console.WriteLine("mFootstepMaterial: '{0}'", mFootstepMaterial);

                byte[] flags_byteStruct = ByteFunctions.AllocateBytes(4, fileBytes, bytePointerPosition);
                mTri.mFlags = ConvertStructs.Get_Flags(flags_byteStruct);
                Console.WriteLine("mFlags: '{0}'", mTri.mFlags.mFlags);
                bytePointerPosition += 4;

                mTri.mNormal = ByteFunctions.ReadLong(fileBytes, ref bytePointerPosition);
                //mTri.mNormal = ByteFunctions.ReadInt(fileBytes, ref bytePointerPosition);
                Console.WriteLine("mNormal: '{0}'", mTri.mNormal);

                mTri.mQuadBuddy = ByteFunctions.ReadLong(fileBytes, ref bytePointerPosition);
                //mTri.mQuadBuddy = ByteFunctions.ReadInt(fileBytes, ref bytePointerPosition);
                Console.WriteLine("mQuadBuddy: '{0}'", mTri.mQuadBuddy);

                mTri.mMaxRadius = ByteFunctions.ReadFloat(fileBytes, ref bytePointerPosition);
                Console.WriteLine("mMaxRadius: '{0}'", mTri.mMaxRadius);

                int mVertsSize = ByteFunctions.ReadInt(fileBytes, ref bytePointerPosition);
                Console.WriteLine("mVertsSize: '{0}'", mVertsSize);

                mTri.mVerts = new int[mVertsSize];

                //public long mNormal;
                //public long mQuadBuddy;
                //public float mMaxRadius;
                //public int[] mVerts; //SArray<int,3>
                //public Edge[] mEdgeInfo; //SArray<WalkBoxes::Edge,3>
                //public int[] mVertOffsets; //SArray<int,3> 
                //public float[] mVertScales; //SArray<float,3>
            }
            */
        }
    }
}
