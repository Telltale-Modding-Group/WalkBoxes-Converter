﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wbox_console.Telltale
{
    public struct WalkBoxes
    {
        public string mName;
        public Tri[] mTris;
        public Vert[] mVerts;
        public Vector3[] mNormals;
        public Quad[] mQuads;
    }
}
