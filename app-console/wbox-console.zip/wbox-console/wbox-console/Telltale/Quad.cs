﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wbox_console.Telltale
{
    public struct Quad
    {
        public int[] mVerts; //SArray<int,4>
    }
}
